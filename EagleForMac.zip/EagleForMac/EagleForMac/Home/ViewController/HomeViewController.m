//
//  HomeViewController.m
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HomeViewController.h"
#import "Masonry.h"
#import "NetWorking.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
    [self setupSubviews];
    [self requestData];
}

- (void)setupSubviews
{
    NSText *text = [NSText new];
    text.textColor = [NSColor whiteColor];
    text.string = @"EAGLE";
    text.backgroundColor = [NSColor clearColor];
    text.font = [NSFont boldSystemFontOfSize:22];
    text.editable = NO;
    [self.view addSubview:text];
    [text mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.height.equalTo(@80);
        make.left.equalTo(self.view).offset(20);
        make.top.equalTo(self.view).offset(20);
    }];
}

- (void)requestData
{
//    [[NetWorking sharedManagerWithBaseUrl:nil] requestWithMethod:POST Url:@"v4/session" Parameter:@{@"email":@"pant@linkstec.com",@"password":@"pantao19911125"} DownloadProgress:nil SuccessBlock:^(id responseBody) {
//        NSLog(@"responseBody: %@",responseBody);
//    } FailureBlock:^(NSDictionary *error) {
//        NSLog(@"error: %@",error);
//    }];
    [[NetWorking sharedManagerWithBaseUrl:nil] requestWithMethod:GET Url:@"v3/projects?private_token=-9Pcd7xyXBcsSCP4k7Bv/" Parameter:nil DownloadProgress:nil SuccessBlock:^(id responseBody) {
        NSLog(@"responseBody: %@",responseBody);
    } FailureBlock:^(NSDictionary *error) {
        NSLog(@"error: %@",error);
    }];
}

@end

//
//  HomeWindowController.m
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HomeWindowController.h"
#import "HomeViewController.h"
#import "NetWorking.h"

@interface HomeWindowController ()
{
    HomeViewController *_homeVC;
}

@end

@implementation HomeWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    [NetWorking sharedManagerWithBaseUrl:@"http://192.168.2.94:10080/api/"];
    [self setup];
}

- (void)setup
{
    self.window.backgroundColor = [NSColor colorWithRed:0.67 green:0.20 blue:0.10 alpha:1.00];
    CGSize size = CGSizeMake(1000, 670);
    self.window.minSize = size;
    self.window.maxSize = size;
    [self.window setContentSize:size];
    self.window.maxFullScreenContentSize = CGSizeMake([NSScreen mainScreen].frame.size.width, [NSScreen mainScreen].frame.size.height);
    _homeVC = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle: nil];
//    [self.window setContentView:_homeVC.view];
    [self setContentViewController:_homeVC];
}

//唤醒了,开始准备...
- (void)awakeFromNib
{
    if ([NSWindow instancesRespondToSelector:@selector(setTitleVisibility:)]) {
        self.window.titleVisibility = NSWindowTitleHidden; //隐藏标题,不在文档里,哈.
        self.window.titlebarAppearsTransparent = YES; //标题栏透明,也是文档没有的玩意
        self.window.styleMask |= NSWindowStyleMaskFullSizeContentView; //全尺寸
    }
}

@end

//
//  ViewController.h
//  EagleForMac
//
//  Created by pantao on 2017/11/17.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end


const qs = require('qs')
const Mock = require('mockjs')
const config = require('../utils/config')

const { APIV3 } = config

module.exports = {
  [`POST ${APIV3}/announcements/announcements`](req, res) {
    res.status(200).json({
      data: [
        {
          time: '昨天 13:09',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '2018-10-01',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '昨天 13:09',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '2018-10-01',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '昨天 13:09',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '2018-10-01',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        },
        {
          time: '昨天 13:09',
          img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
          title: '关于公司产品制度再次强调',
          detailTitle: '招行IPO上市停滞不前',
          des: '欢迎来到经济大数据平台提供的最新客户提醒，第三季度财报显示，招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不招行的IPO计划停滞不',
        }
      ],
      total: 3,
    })
  },
}

import React from 'react';
import { Layout } from 'components';
import { connect } from 'dva';
import { ListView } from 'antd-mobile';
import classnames from 'classnames'
import styles from './index.less'
import { routerRedux } from 'dva/router';

function Announcement({
  dispatch,
  history,
  announcement,
  loading
}) {

  const { data, dataBlobs, sectionIDs, rowIDs, isLoading } = announcement

  const getSectionData = (dataBlob, sectionID) => dataBlob[sectionID];
  const getRowData = (dataBlob, sectionID, rowID) => dataBlob[rowID];

  const dataSource = new ListView.DataSource({
      getRowData,
      getSectionHeaderData: getSectionData,
      rowHasChanged: (row1, row2) => row1 !== row2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2,
  });

  function MyBody(props) {
    return (
      <div className="am-list-body my-body">
        <span style={{ display: 'none', backgroundColor: 'red'}}>you can custom body wrap element</span>
        {props.children}
      </div>
    );
  }

  // row之前的间距
  const separator = (sectionID, rowID) => (
    <div
      key={`${sectionID}-${rowID}`}
      className={styles.list_separator}
    />
  );

  // row
  let index = data.length - 1;
  const row = (rowData, sectionID, rowID) => {
    if (index < 0) {
      index = data.length - 1;
    }
    const obj = data[index--];
    return (
      <div key={rowID} className={styles.list_row_container}>
        <div className={styles.list_row_title}>{obj.time}</div>
        <div className={styles.list_row_info_container}>
          <img className={styles.list_row_img} src={obj.img} alt="" />
          <div className={styles.list_row_content_container} onClick={gotoDetail}>
            <div className={styles.list_row_content_title}>{obj.title}</div>
            <div className={styles.list_row_content_detail_title}>{obj.detailTitle}</div>
            <div className={styles.list_row_content_des}>{obj.des}</div>
          </div>
        </div>
      </div>
    );
  };

  // 触底
  function onEndReached() {
    console.log("我触底了");
    dispatch({ type:'announcement/getAnnouncementList', payload:'' })
  }

  // 去详情页面
  function gotoDetail() {
    console.log("???????????????????????????");
    dispatch({ type:'announcement/pushToDetail', payload:'' })
  }

  return (
    <ListView
        dataSource={dataSource.cloneWithRowsAndSections(dataBlobs, sectionIDs, rowIDs)}
        renderFooter={() => (<div className={styles.list_footer}>
          {isLoading ? 'Loading...' : 'Loaded'}
        </div>)}
        renderBodyComponent={() => <MyBody />}
        renderRow={row}
        renderSeparator={separator}
        style={{
          height: '100%',
          overflow: 'auto',
        }}
        pageSize={4}
        onScroll={() => { console.log('scroll'); }}
        scrollRenderAheadDistance={500}
        onEndReached={onEndReached}
        onEndReachedThreshold={10}
    />
  );
}

Announcement.propTypes = {
};
export default connect(({ announcement, loading }) => ({ announcement, loading }))(Announcement);


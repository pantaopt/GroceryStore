import React from 'react';
import { Layout } from 'components';
import { connect } from 'dva';
import classnames from 'classnames'
import styles from './index.less'

function AnnouncementDetail({
  dispatch,
  history,
  announcementDetail,
  loading
}) {

  return (
    <div className={styles.homeContainer}>detail</div>
  );
}

AnnouncementDetail.propTypes = {
};
export default connect(({ announcementDetail, loading }) => ({ announcementDetail, loading }))(AnnouncementDetail);


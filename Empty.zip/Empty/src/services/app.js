import { request, config } from 'utils'

const { api } = config;
const { user, userInfo, userLogout, userLogin } = api;

console.log(userInfo, userLogout, userLogin);

export async function login(params) {
  return request({
    url: userLogin,
    method: 'post',
    data: params,
  })
}

export async function logout(params) {
  return request({
    url: userLogout,
    method: 'get',
    data: params,
  })
}
export async function query (params) {
  return request({
    url: user.replace('/:id', ''),
    method: 'get',
    data: params,
  })
}
// export async function query (params) {
//   return request({
//     url: userInfo,
//     method: 'post',
//     data:'busiNo=customerHtml5.SelectCustInfos&param={\"custSecName\":null,\"limit\":\"10\",\"start\":\"0\"}'
//   })
// }
// 查询客户
export async function CustomQuery (params) {
  // 解析数据
  const custSecName = params && params.custSecName ? '\"custSecName\":' + JSON.stringify(params.custSecName) : '\"custSecName\":' + null

  const queryData = params ? `busiNo=${params.busiNo}&param={${custSecName},\"limit\":${params.limit},\"start\":${params.start}}` : 'busiNo=customerHtml5.SelectCustInfos&param={\"custSecName\":null,\"limit\":\"10\",\"start\":\"0\"}'

  return request({
    url: userInfo,
    method: 'post',
    data: encodeURI(queryData),
  })
}
// 删除客户
export async function custDelete (params) {
  // 解析数据
  const queryData = `busiNo=${params.busiNo}&param={\"list\":[${params.list}]}`

  return request({
    url: userInfo,
    method: 'post',
    data: queryData,
  })
}
// 客户状态
export async function listingStatusDicQuery() {
  // 解析数据
  const queryData = `busiNo=base.SelectDdmanagerByType&param={\"type\":\"listingStatus\"}`

    return request({
      url: userInfo,
      method: 'post',
      data: queryData,
    })
}
//地区字典
export async function AreaTypeDicQuery() {
  // 解析数据
  const queryData = `busiNo=base.SelectDdmanagerByType&param={\"type\":\"areaType\"}`

    return request({
      url: userInfo,
      method: 'post',
      data: queryData,
    })
}
export async function CustLevelDicQuery (param) {
  // 解析数据
  const queryData = `busiNo=base.SelectDdmanagerByType&param={\"type\":\"custLevel\"}`

    return request({
      url: userInfo,
      method: 'post',
      data: queryData,
    })
  }
  export async function TypeFlagDicQuery (param) {
    // 解析数据
    const queryData = `busiNo=base.SelectDdmanagerByType&param={\"type\":\"typeflag\"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
    }
    // 添加客户
  export async function  custAdd (param) {
    let queryD = '',strValue = null
    // 解析数据
    for (let key of Object.keys(param)){
      strValue = param[key] ? `"${param[key]}"` : null
      queryD = queryD + `\"${key}\":` + strValue + ','
    }
    queryD = queryD.substr(0,queryD.length-1)

    const queryData = `busiNo=customer.AddCustInfo&param={${queryD}}`

      return request({
        url: userInfo,
        method: 'post',
        data: encodeURI(queryData),
      })
  }
   // 查询单个用户信息
   export async function  custInfoBycustId (param) {
    //
    const queryData = `busiNo=customer.SelectCustInfoByCustId&param={\"custId\":"${param.custId}"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }

   // 编辑客户
  export async function  custUpdate (param) {
    // 解析数据
    let queryD = '',strValue = null
    for (let key of Object.keys(param)){
      strValue = param[key] ? `"${param[key]}"` : null
      queryD = queryD + `\"${key}\":` + strValue + ','
    }
    queryD = queryD.substr(0,queryD.length-1)
    const queryData = `busiNo=customer.UpdateCustInfo&param={${queryD}}`

      return request({
        url: userInfo,
        method: 'post',
        data: encodeURI(queryData),
      })
  }

  // 调取登陆信息
  export async function  logInfo (param) {
    // 解析数据
    const queryData = `busiNo=baseHtml5.SearchLoginMessage&param={}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }
  // 查证监会行业1级
  export async function  ZJHIndustryLevel1 () {
    // 解析数据
    const queryData = `busiNo=customerHtml5.SelectIndustryClassification&param={\"type\":\"1\"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }
  // 查证监会行业2级
  export async function  ZJHIndustryLevel2 () {
    // 解析数据
    const queryData = `busiNo=customerHtml5.SelectIndustryClassification&param={\"type\":\"2\"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }
  // 查证升级数据
  export async function  Province () {
    // 解析数据
    const queryData = `busiNo=customerHtml5.SelectCityDate&param={\"type\":\"1\"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }
  // 查证实际数据
  export async function  City () {
    // 解析数据
    const queryData = `busiNo=customerHtml5.SelectCityDate&param={\"type\":\"2\"}`

      return request({
        url: userInfo,
        method: 'post',
        data: queryData,
      })
  }
  // 人员数查询
export async function pSelectAllMemberQuery () {
  return request({
    url: userInfo,
    method: 'post',
    data: 'busiNo=baseHtml5.SelectAllMember&param={}',
  })
}

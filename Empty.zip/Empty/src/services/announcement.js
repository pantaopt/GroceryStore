import { request, config } from 'utils'

const { api } = config
const { announcements } = api
export async function getAnnouncements(params) {
  return request({
    url: `${announcements}/announcements`,
    method: 'post',
    data: params,
  })
}
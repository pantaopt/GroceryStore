import { request, config } from 'utils'

const { api } = config
const { announcementDetail } = api
export async function getAnnouncementDetail(params) {
  return request({
    url: `${announcementDetail}/announcementDetail`,
    method: 'post',
    data: params,
  })
}
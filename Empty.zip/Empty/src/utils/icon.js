module.exports = {
  yingyong: 'yingyong.svg',
  yingyong_s: 'yingyong_S.svg',
};

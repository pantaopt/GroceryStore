// const HOST = 'http://122.193.26.154:8245/';
const HOST = 'http://192.168.32.62:8090/';
const LOGIN = 'ibf/m/MLogin';
const API = 'ibf/lpageconn';
const APIV1 = '/api/v1';
const APIV2 = '/api/v2';
const APIV3 = '/api/v3';

module.exports = {
  name: '投行',
  prefix: 'zszq',
  footerText: '凌志软件  © 2018 linkstec',
  logo: 'logo.png',
  iconFontCSS: 'iconfont.css',
  iconFontJS: 'iconfont.js',
  // CORS: ["http://122.193.26.154:8245"],
  CORS: ["http://192.168.32.62:8090"],
  openPages: ['/login'],
  apiPrefix: '/api/v1',
  HOST,
  LOGIN,
  APIV1,
  APIV2,
  APIV3,
  api: {
    userLogin: `${API}${LOGIN}`,
    userLogout: `${API}ibf/mLogout`,
    userInfo: `${API}${API}`,
    flowQuery: `${API}${API}`,
    users: `${APIV1}/users`,
    posts: `${APIV1}/posts`,
    user: `${APIV1}/user/:id`,
    home: `${APIV3}/home`,
    flow: `${APIV3}/flow`,
    announcements: `${APIV3}/announcements`,
    announcementDetail: `${APIV3}/announcementDetail`,
  },
}

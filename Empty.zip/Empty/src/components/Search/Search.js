import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { SearchBar } from 'antd-mobile';
import styles from './Search.less';

class Search extends Component {
  constructor(props){
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }
  handleSubmit(value) {
    this.props.onSearch(value);
  }
  onChange(value){
    if(value===''){
      this.props.onSearch('');
    }
  }
  render() {
    return (<SearchBar  placeholder="搜索" defaultValue="" onSubmit={this.handleSubmit} onChange={this.onChange}  showCancelButton={false} />);
  }
}


Search.propTypes = {
  onSearch: PropTypes.func,
};

export default Search;


import modelExtend from 'dva-model-extend'

export default {
  namespace: 'common',
  state: {
  },
  subscriptions: {
    setup ({ dispatch }) {
     
    },
},
  reducers: {
    updateState (state, { payload }) {
      return {
        ...state,
        ...payload,
      }
    },

  },
}


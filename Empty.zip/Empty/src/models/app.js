/* global window */
/* global document */
/* global location */
import { parse } from 'qs'
import pathToRegexp from 'path-to-regexp';
import config from 'config'
import modelExtend from 'dva-model-extend'
import { logout } from 'services/app'
import queryString from 'query-string'
import { pageModel } from './common'

const { prefix } = config

export default {
  namespace: 'app',
  state: {
    locationPathname: '',
    locationQuery: {},
    titleText: '投行项目',
  },
  subscriptions: {

    setupHistory({ dispatch, history }) {
      history.listen((location) => {
        dispatch({
          type: 'updateState',
          payload: {
            locationPathname: location.pathname,
            locationQuery: queryString.parse(location.search),
          },
        })
      })
    },

  },
  effects: {

    * setTitle({ payload },{put}){
      yield put({ type: 'updateState', payload: { titleText:payload }})
    },
    * logout({
      payload,
    }, { call, put }) {
      const data = yield call(logout, parse(payload))
      if (data.success) {
        yield put({ type: 'query' })
      } else {
        throw (data)
      }
    },

  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload,
      }
    },
  
  },
}

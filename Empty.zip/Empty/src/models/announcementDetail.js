import { routerRedux } from 'dva/router'
import { pageModel } from './common'
import { getAnnouncementDetail } from 'services/announcementDetail'

export default{
  namespace: 'announcementDetail',
  
  state: {
  },
  subscriptions: {
    setup({ dispatch, history }) {
      history.listen(({pathname}) => {
          if(pathname === '/announcement/announcementDetail'){
                  dispatch({
                      type: 'getAnnouncementDetail',
                  })
          }
      })
    }
  },
  effects: {
    * getAnnouncementDetail({ payload = {} }, { call, put }) {
      const {data} = yield call(getAnnouncementDetail,{})
      if(data){
        yield put({ type: 'updateState', payload: { } })
      }
    }
  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload,
      }
    },
  },
}

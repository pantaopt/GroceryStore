import { routerRedux } from 'dva/router'
import { pageModel } from './common'
import { getAnnouncements } from 'services/announcement'

const NUM_SECTIONS = 1;
let data_temp = [];

export default{
  namespace: 'announcement',
  
  state: {
    isLoading: true,
    data: [],
    dataBlobs: {},
    sectionIDs: [],
    rowIDs: []
  },
  subscriptions: {
    setup({ dispatch, history }) {
      history.listen(({pathname}) => {
          if(pathname === '/announcement'){
                  dispatch({
                      type: 'getAnnouncementList',
                  })
          }
      })
    }
  },
  effects: {
    * getAnnouncementList({ payload = {} }, { call, put }) {
      const {data} = yield call(getAnnouncements,{})
      if(data.length){
        data_temp = data_temp.concat(data);

        const dataBlobs_temp = {};
        let sectionIDs_temp = [];
        let rowIDs_temp = [];

        let num_rows_per_section = data_temp.length;

        for (let i = 0; i < NUM_SECTIONS; i++) {
          const ii = i;
          const sectionName = `Section ${ii}`;
          sectionIDs_temp.push(sectionName);
          dataBlobs_temp[sectionName] = sectionName;
          rowIDs_temp[ii] = [];
      
          for (let jj = 0; jj < num_rows_per_section; jj++) {
            const rowName = `S${ii}, R${jj}`;
            rowIDs_temp[ii].push(rowName);
            dataBlobs_temp[rowName] = rowName;
          }
        }
        sectionIDs_temp = [...sectionIDs_temp];
        rowIDs_temp = [...rowIDs_temp];

        yield put({ type: 'updateState', payload: { data:data_temp, dataBlobs:dataBlobs_temp, sectionIDs:sectionIDs_temp, rowIDs:rowIDs_temp } })
      }
    },
    * pushToDetail({ payload = {} }, { call, put }) {
      yield put(routerRedux.push('/announcement/announcementDetail'));
    },
  },
  reducers: {
    updateState(state, { payload }) {
      return {
        ...state,
        ...payload,
      }
    },
  },

}

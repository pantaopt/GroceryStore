import { AppRegistry } from 'react-native';

import MainNavigator from './views/MainNavigator';

AppRegistry.registerComponent('HelloWorld', () => MainNavigator);

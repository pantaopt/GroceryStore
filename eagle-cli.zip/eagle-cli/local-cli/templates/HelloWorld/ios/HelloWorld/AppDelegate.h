//
//  AppDelegate.h
//  HelloWorld
//
//  Created by 潘涛 on 2017/9/7.
//  Copyright © 2017年 LZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


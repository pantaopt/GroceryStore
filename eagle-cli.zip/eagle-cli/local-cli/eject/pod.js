#!/usr/bin/env node
var shell = require('shelljs');
const path = require('path');
const fs = require('fs');

var PROJECT_PATH = function (projectName) {
    return path.resolve(
        process.cwd(),
        projectName.join(""),
        'ios'
    );
};

function podInstall(projectName) {
    console.log("projectName:" + PROJECT_PATH(projectName));
    PROJECT_PATH(projectName);
    shell.exec('pod install');
}

module.exports = {
    podInstall: podInstall
};
'use strict';

const copyProjectTemplateAndReplace = require('../generator/copyProjectTemplateAndReplace');
const path = require('path');
const fs = require('fs');
const pod = require('./pod');
var argv = require('minimist')(process.argv.slice(2));


console.log(argv);
/**
 * 获取当前cd当前文件夹路径
 * @returns {Promise.<*>}
 * @constructor
 */
var PROJECT_PATH = function () {
  return path.resolve(
      process.cwd()
  );
};

var PROJECT_EAGLE_CONFIG_PATH = function () {
  return path.resolve(
      process.cwd()
  );
};


function eject(projectName) {
  console.log("name:"+projectName);
  const doesIOSExist = fs.existsSync(path.resolve('ios'));
  const doesAndroidExist = fs.existsSync(path.resolve('android'));
  if (doesIOSExist && doesAndroidExist) {
    console.error('iOS和Android工程已经存在! 请删除工程后再创建');
    process.exit(1);
  }

  let appConfig = null;
  try {
	var appjson = PROJECT_PATH() +'/...eagle.json';
    console.log(appjson);
	appConfig=JSON.parse(fs.readFileSync(appjson));
  } catch(e) {
    console.error(
      `创建iOS或者Android工程需要 \`...eagle.json\` 配置文件 ` + PROJECT_EAGLE_CONFIG_PATH +
      `/...eagle.json, and it must at least specify a \`name\` for the project ` +
      `name, and a \`displayName\` for the app's home screen label.`
    );
    process.exit(1);
  }
  const iOSProjectName = appConfig.iOS.projectName;
  const androidProjectName = appConfig.android.projectName;
  if (!iOSProjectName || !androidProjectName) {
    console.error(
      `App \`name\` must be defined in the \`...eagle.json\` config file to define the project projectName. `+
      `It must not contain any spaces or dashes.`
    );
    process.exit(1);
  }
  const displayName = appConfig.iOS.displayName;
  if (!displayName) {
    console.error(
      `App \`displayName\` must be defined in the \`app.json\` config file, to define the label ` +
      `of the app on the home screen.`
    );
    process.exit(1);
  }

  const iOSTemplateOptions = { displayName:displayName,  iOS:appConfig.iOS};
  const androidTemplateOptions = { android: appConfig.android};

  console.log(iOSTemplateOptions);
  console.log(androidTemplateOptions);

  console.log("CLI_MODULE_PATH:"+ PROJECT_PATH()+ "/"+ projectName +'/ios');
  if (!doesIOSExist) {
    console.log('创建iOS文件夹.');
    copyProjectTemplateAndReplace(
	  path.resolve(__dirname, '..')+'/templates/HelloWorld/ios',
      path.resolve(PROJECT_PATH()+ "/"+ projectName +'/ios'),
      iOSProjectName,
      iOSTemplateOptions
    );
    pod.podInstall(projectName);
  }

  if (!doesAndroidExist) {
    console.log('创建Android文件夹.');
    copyProjectTemplateAndReplace(
	  path.resolve(__dirname, '..')+'/templates/HelloWorld/android',
      path.resolve(PROJECT_PATH()+ "/" + projectName + '/android'),
      androidProjectName,
      androidTemplateOptions
    );
  }

}

module.exports = {
  name: 'eject',
  description: 'Re-create the iOS and Android folders and native code',
  func: eject,
  options: [],
};

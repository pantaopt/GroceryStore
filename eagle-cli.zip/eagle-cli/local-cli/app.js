#!/usr/bin/env node
var fs = require('fs');
const path = require('path');
var shell = require('shelljs');
var clijs = __dirname+'/cli.js';

function init(name, verbose) {
	var command = 'node '+clijs+' eject '+ name;
	shell.exec(command);
}

module.exports = {
	init: init
};
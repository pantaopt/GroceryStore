#!/usr/bin/env node

/**
 * Copyright (c) 2017-Linkstec, Inc.
 * All rights reserved.
 */

'use strict';

var fs = require('fs');
var path = require('path');
var exec = require('child_process').exec;
var spawn = require('child_process').spawn;
var chalk = require('chalk');
var prompt = require('prompt');
var semver = require('semver');

var argv = require('minimist')(process.argv.slice(2));

var CLI_MODULE_PATH = function () {
    return path.resolve(
        process.cwd(),
        'node_modules',
        'react-native',
        'cli.js'
    );
};

var REACT_NATIVE_PACKAGE_JSON_PATH = function () {
    return path.resolve(
        process.cwd(),
        'node_modules',
        'react-native',
        'package.json'
    );
};

checkForVersionArgument();
var cli;
var cliPath = CLI_MODULE_PATH();
if (fs.existsSync(cliPath)) {
    cli = require(cliPath);
}
// minimist api
var commands = argv._;
if (cli) {
    cli.run();
} else {
    if (commands.length === 0) {
        console.error(
            '是否想执行`eagle create`?'
        );
        process.exit(1);
    }
    switch (commands[0]) {
        case 'create':
            if (!commands[1] || !commands[2]) {
                console.error(
                    '使用: eagle create <ProjectType> <ProjectName> [--verbose]'
                );
                process.exit(1);
            } else {
                init(commands[1], commands[2], argv.verbose);
            }
            break;
        default:
            console.error(
                '未知命令!'
            );
            process.exit(1);
            break;
    }
}

/**
 * 验证创建工程的名字是否与平台重合
 * @param name
 */
function validatePackageName(name) {
    if (!name.match(/^[$A-Z_][0-9A-Z_$]*$/i)) {
        console.error(
            '"%s" 不是一个有效的项目名称。.请使用英文字母以及数字组合',
            name
        );
        process.exit(1);
    }

    if (name === 'React') {
        console.error(
            '"%s" is not a valid name for a project. Please do not use the ' +
            'reserved word "React".',
            name
        );
        process.exit(1);
    }
}

/**
 * 创建一个工程
 * @param type 工程类型  native ios  android  react-native  vue  angular
 * @param name 工程名称
 * @param verbose
 */
function init(type,  name,  verbose) {
    validatePackageName(name);

    if (fs.existsSync(name)) {
        createAfterConfirmation(name, verbose);
    } else {
        createProject(type, name, verbose);
    }
}

/**
 * 如果对应路径存在  则提示是否退出
 * @param name
 * @param verbose
 */
function createAfterConfirmation(name, verbose) {
    prompt.start();

    var property = {
        name: 'yesno',
        message: '文件夹 ' + name + ' 已经存在. 是否继续?',
        validator: /y[es]*|n[o]?/,
        warning: '必须输入 yes or no',
        default: 'no'
    };

    prompt.get(property, function (err, result) {
        if (result.yesno[0] === 'y') {
            createProject(name, verbose);
        } else {
            console.log('取消项目创建');
            process.exit();
        }
    });
}

/**
 * 创建工程
 * @param type
 * @param name
 * @param verbose
 */
function createProject(type, name, verbose) {
    var root = path.resolve(name);
    var projectName = path.basename(root);
    console.log('即将帮您在'+ root +'文件夹下创建'+ type +'类型的'+ projectName+'工程');

    if (!fs.existsSync(root)) {
        fs.mkdirSync(root);
    }

    switch (type){
        case 'native': 
            createNativeProject(name, verbose);
            break;
        case 'ios':
            createiOSProject(name, verbose);
            break;
        case 'android':
            createAndroidProject(name, verbose);
            break;
        case 'react-native':
            createRNProject(name, verbose);
    }
}

/**
 * 创建原生工程
 * @param name
 * @param verbose
 */
function createNativeProject(name, verbose) {
    var cli = require("./local-cli/app");
    cli.init(name, verbose);
}

/**
 * 创建iOS工程
 */
function createiOSProject() {
    
}

/**
 * 创建android工程
 */
function createAndroidProject() {

}

/**
 * 创建react-native工程
 */
function createRNProject() {
    var packageJson = {
        name: projectName,
        version: '0.0.1',
        private: true
    };
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(packageJson));
    process.chdir(root);

    console.log('Installing eagle package from npm...');

    if (verbose) {
        runVerbose(root, projectName, rnPackage);
    } else {
        run(root, projectName, rnPackage);
    }
}

function getInstallPackage(rnPackage) {
    var packageToInstall = 'react-native';
    var valideSemver = semver.valid(rnPackage);
    if (valideSemver) {
        packageToInstall += '@' + valideSemver;
    } else if (rnPackage) {
        // for tar.gz or alternative paths
        packageToInstall = rnPackage;
    }
    return packageToInstall;
}

function run(root, projectName, rnPackage) {
    exec('npm install --save --save-exact ' + getInstallPackage(rnPackage), function (e, stdout, stderr) {
        if (e) {
            console.log(stdout);
            console.error(stderr);
            console.error('`npm install --save --save-exact react-native` failed');
            process.exit(1);
        }

        checkNodeVersion();

        var cli = require(CLI_MODULE_PATH());
        cli.init(root, projectName);
    });
}

function runVerbose(root, projectName, rnPackage) {
    var proc = spawn('npm', ['install', '--verbose', '--save', '--save-exact', getInstallPackage(rnPackage)], {stdio: 'inherit'});
    proc.on('close', function (code) {
        if (code !== 0) {
            console.error('`npm install --save --save-exact react-native` failed');
            return;
        }
        cli = require(CLI_MODULE_PATH());
        cli.init(root, projectName);
    });
}


/**
 * 检查eagle平台使用node的最低版本
 */
function checkNodeVersion() {
    var packageJson = require('./package.json');
    if (!packageJson.engines || !packageJson.engines.node) {
        return;
    }
    if (!semver.satisfies(process.version, packageJson.engines.node)) {
        console.error(chalk.red(
                '当前版本为 Node %s 但是Eagle platform 需要 %s. ' +
                '请使用支持的Node版本.\n'
            ),
            process.version,
            packageJson.engines.node);
    }
}


/**
 * 检查是否是查看版本命令
 * 打印 eagle-cli对应的版本
 */
function checkForVersionArgument() {
    if (argv._.length === 0 && (argv.v || argv.version)) {
        console.log('eagle-cli 版本: ' + require('./package.json').version);
        process.exit();
    }
}

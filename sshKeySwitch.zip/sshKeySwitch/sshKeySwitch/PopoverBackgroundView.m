//
//  PopoverBackgroundView.m
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import "PopoverBackgroundView.h"

@implementation PopoverBackgroundView

-(void)drawRect:(NSRect)dirtyRect
{
    [[NSColor colorWithRed:0.7 green:0.7 blue:0.7 alpha:0.6] set]; // 此处设置背景颜色
    NSRectFill(self.bounds);
}
@end

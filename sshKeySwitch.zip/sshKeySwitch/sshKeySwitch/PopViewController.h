//
//  PopViewController.h
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PopViewController : NSViewController

@property (nonatomic, strong) NSString *msg;

@end

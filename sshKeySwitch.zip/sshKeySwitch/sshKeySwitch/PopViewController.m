//
//  PopViewController.m
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import "PopViewController.h"
#import "PopoverRootView.h"

@interface PopViewController ()

@property (nonatomic, strong) NSText *text;

@end

@implementation PopViewController

- (void)loadView
{
    [super loadView];
    PopoverRootView *popRootV = [PopoverRootView new];
    self.view = popRootV;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
    [self setupSubviews];
}

- (void)setupSubviews
{
    self.text = [[NSText alloc] initWithFrame:CGRectMake(0, -3, 250, 20)];
//    self.text.textColor = [NSColor whiteColor];
    self.text.backgroundColor = [NSColor clearColor];
    self.text.font = [NSFont boldSystemFontOfSize:12];
    self.text.editable = NO;
    [self.view addSubview:self.text];
}

- (void)setMsg:(NSString *)msg
{
    _msg = msg;
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
    CGSize size = [msg boundingRectWithSize:CGSizeMake(MAXFLOAT, 0.0) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
    [self.text setFrame:CGRectMake(0, -3, size.width, 20)];
    self.text.string = msg;
}

@end

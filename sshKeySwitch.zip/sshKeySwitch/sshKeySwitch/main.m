//
//  main.m
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"

int main(int argc, const char * argv[]) {
    NSApplication *app = [NSApplication sharedApplication];
    id delegate = [[AppDelegate alloc] init];
    app.delegate = delegate;
    return NSApplicationMain(argc, (const char**)argv);
}

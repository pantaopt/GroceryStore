//
//  AppDelegate.m
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import "AppDelegate.h"
#import "STPrivilegedTask.h"
#import "PopViewController.h"

@interface AppDelegate ()

@property (nonatomic, strong) NSStatusItem * statusItem;
@property (nonatomic,strong) NSPopover *popover;
@property (nonatomic,strong) PopViewController *popVC;
@property (nonatomic, assign) BOOL fristSh;

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    _fristSh = YES;
    [self ejectShell:@"/bin/sh script.sh"];
}

#pragma mark -- 开机自启动
#ifdef debug
- (void)autoOpen
{
    LSSharedFileListRef loginItems = LSSharedFileListCreate(NULL, kLSSharedFileListSessionLoginItems, NULL);
    //url为app所在的目录
    CFURLRef url = (CFURLRef)[NSURL fileURLWithPath:@"/Applications"];
    LSSharedFileListItemRef item = LSSharedFileListInsertItemURL(loginItems, kLSSharedFileListItemLast, NULL, NULL, url, NULL, NULL);
    CFRelease(item);
    CFRelease(loginItems);
}
#endif

#pragma mark -- 设置statusItem

- (void)setupStatusWithSshKeys:(NSArray *)sshKeys
{
    self.statusItem        = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    self.statusItem.title  = @"";
    self.statusItem.image  = [NSImage imageNamed:@"sshKeySwitch"];
    self.statusItem.target = self;
    [self.statusItem setToolTip:@"选择以切换sshKey"];
    NSMenu * menu = [[NSMenu alloc] init];
    if (sshKeys.count == 0) {
        //    self.statusItem.action = @selector(openWindow:);
        [menu addItemWithTitle:@"未设置sshKey" action:nil keyEquivalent:@""];
    }else {
        for (NSString *sshKey in sshKeys) {
            NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:sshKey action:@selector(toggleNotifications:) keyEquivalent:@""];
            item.image = [NSImage imageNamed:@"key"];
            [item setTarget:self];
            [menu addItem:item];
        }
    }
    NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:@"退出sshKeySwitch" action:@selector(quit) keyEquivalent:@""];
    [item setTarget:self];
    [menu addItem:item];
    self.statusItem.menu = menu;
}

#pragma mark -- 退出app

- (void)quit
{
    [NSApp terminate:self];
}

#pragma mark -- NSMenuItem的点击事件

- (void)toggleNotifications:(NSMenuItem *)item
{
    NSString *title = item.title;
    [self ejectShell:[NSString stringWithFormat:@"/bin/sh sshKeySwitch.sh %@",title]];
}

#pragma mark -- 执行shell脚本

- (void)ejectShell:(NSString *)cmd
{
    NSTask *task = [[NSTask alloc] init];
    
    NSMutableArray *components = [[cmd componentsSeparatedByString:@" "] mutableCopy];
    task.launchPath = components[0];
    [components removeObjectAtIndex:0];
    task.arguments = components;
    task.currentDirectoryPath = [[NSBundle  mainBundle] resourcePath];
    
    NSPipe *outputPipe = [NSPipe pipe];
    [task setStandardOutput:outputPipe];
    [task setStandardError:outputPipe];
    NSFileHandle *readHandle = [outputPipe fileHandleForReading];
    
    [task launch];
    [task waitUntilExit];
    NSData *outputData = [readHandle readDataToEndOfFile];
    NSString *outputString = [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
    //    NSString *exitStr = [NSString stringWithFormat:@"Exit status: %d", task.terminationStatus];
    
    NSLog(@">>>>>>>>>>>>outputString: %@",outputString);
    //    NSLog(@">>>>>>>>>>>>exitStr: %@",exitStr);
    if (!_fristSh) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
        CGSize size = [outputString boundingRectWithSize:CGSizeMake(MAXFLOAT, 0.0) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
        [self.popover setContentSize:NSMakeSize(size.width, 20.0f)];
        [self.popover showRelativeToRect:[self.statusItem.button bounds] ofView:self.statusItem.button preferredEdge:NSRectEdgeMaxY];
        self.popVC.msg = outputString;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [_popover close];
        });
        return;
    }
    _fristSh = NO;
    NSMutableArray *sshKeys = [NSMutableArray array];
    if (task.terminationStatus == 0) {
        NSArray *temp_sshKeys = [outputString componentsSeparatedByString:@"\n"];
        if (temp_sshKeys.count > 0) {
            for (NSString *sshKey in temp_sshKeys) {
                if ([sshKey rangeOfString:@"host"].location != NSNotFound || [sshKey rangeOfString:@".pub"].location != NSNotFound || [sshKey stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0) {
                    continue;
                }
                [sshKeys addObject:sshKey];
            }
        }
    }
    [self setupStatusWithSshKeys:sshKeys];
}

#pragma mark -- 使用STPrivilegedTask获取root执行shell脚本(待用)

- (void)loadFilesWithSTP
{
    STPrivilegedTask *privilegedTask = [[STPrivilegedTask alloc] init];
    
    NSMutableArray *components = [[@"/bin/sh script.sh" componentsSeparatedByString:@" "] mutableCopy];
    NSString *launchPath = components[0];
    [components removeObjectAtIndex:0];
    
    [privilegedTask setLaunchPath:launchPath];
    [privilegedTask setArguments:components];
    [privilegedTask setCurrentDirectoryPath:[[NSBundle mainBundle] resourcePath]];
    
    //set it off
    OSStatus err = [privilegedTask launch];
    if (err != errAuthorizationSuccess) {
        if (err == errAuthorizationCanceled) {
            NSLog(@"User cancelled");
            return;
        }  else {
            NSLog(@"Something went wrong: %d", (int)err);
            // For error codes, see http://www.opensource.apple.com/source/libsecurity_authorization/libsecurity_authorization-36329/lib/Authorization.h
        }
    }
    
    [privilegedTask waitUntilExit];
    
    NSFileHandle *readHandle = [privilegedTask outputFileHandle];
    NSData *outputData = [readHandle readDataToEndOfFile];
    NSString *outputString = [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
    
    NSString *exitStr = [NSString stringWithFormat:@"Exit status: %d", privilegedTask.terminationStatus];
    
    NSLog(@">>>>>>>>>>>>outputString: %@",outputString);
    NSLog(@">>>>>>>>>>>>exitStr: %@",exitStr);
}

#pragma mark -- popover

- (NSPopover *)popover
{
    if(!_popover) {
        _popover = [[NSPopover alloc]init];
        _popover.appearance = [NSAppearance appearanceNamed:NSAppearanceNameAqua];
        _popover.contentViewController = self.popVC;
        _popover.behavior = NSPopoverBehaviorTransient;
        [_popover setContentSize:NSMakeSize(250.0f, 20.0f)];
    }
    return _popover;
}

- (PopViewController *)popVC
{
    if (!_popVC) {
        _popVC = [[PopViewController alloc] initWithNibName:@"PopViewController" bundle:nil];
    }
    return _popVC;
}

@end

//
//  PopoverRootView.m
//  sshKeySwitch
//
//  Created by pantao on 2017/11/22.
//  Copyright © 2017年 pantao. All rights reserved.
//

#import "PopoverRootView.h"
#import "PopoverBackgroundView.h"

@implementation PopoverRootView

-(void)viewDidMoveToWindow
{
    NSView * aFrameView = [[self.window contentView] superview];
    PopoverBackgroundView * aBGView  =[[PopoverBackgroundView alloc] initWithFrame:aFrameView.bounds];
    aBGView.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [aFrameView addSubview:aBGView positioned:NSWindowBelow relativeTo:aFrameView];
    [super viewDidMoveToWindow];
}

@end

//
//  main.m
//  EagleForMac
//
//  Created by pantao on 2017/11/17.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}

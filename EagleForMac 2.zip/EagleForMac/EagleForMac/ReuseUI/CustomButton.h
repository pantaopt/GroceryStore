//
//  CustomButton.h
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CustomButton : NSButton

@property (nonatomic, strong) NSColor *titleColor;
@property (nonatomic, strong) NSColor *bgColor;
@property (nonatomic, assign) CGFloat fontSize;

@end

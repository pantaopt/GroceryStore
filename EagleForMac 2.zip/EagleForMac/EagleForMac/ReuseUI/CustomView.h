//
//  CustomView.h
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CustomView : NSView

@property (nonatomic, strong) NSColor *bgColor;

@end

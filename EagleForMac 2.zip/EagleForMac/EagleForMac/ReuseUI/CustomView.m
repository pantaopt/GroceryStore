//
//  CustomView.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "CustomView.h"

@implementation CustomView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [self.bgColor ? : [NSColor colorWithRed:0.96f green:0.96f blue:0.96f alpha:1.00f] set];
    NSRectFill(dirtyRect);
    // Drawing code here.
}

@end

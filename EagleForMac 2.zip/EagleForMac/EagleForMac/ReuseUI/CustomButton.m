//
//  CustomButton.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "CustomButton.h"

@implementation CustomButton

- (void)drawRect:(NSRect)dirtyRect
{
    [super drawRect:dirtyRect];
    [self.bgColor ? : [NSColor colorWithRed:0.01f green:0.49f blue:1.00f alpha:1.00f] set];
    self.layer.cornerRadius = 5.f;
    NSRectFill(dirtyRect);
    // Drawing code here.
    if(self.title != nil) {
        NSColor *color =self.titleColor ? : [NSColor whiteColor];
        NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
        [paraStyle setParagraphStyle:[NSParagraphStyle defaultParagraphStyle]];
        [paraStyle setAlignment:NSTextAlignmentCenter];
        //[paraStyle setLineBreakMode:NSLineBreakByTruncatingTail];
        NSDictionary *attrButton = [NSDictionary dictionaryWithObjectsAndKeys:[NSFont systemFontOfSize:self.fontSize ? : 14],NSFontAttributeName, color,NSForegroundColorAttributeName, paraStyle,NSParagraphStyleAttributeName,nil];
        NSAttributedString *btnString = [[NSAttributedString alloc]initWithString:self.title attributes:attrButton];
        CGSize size = [self.title boundingRectWithSize:CGSizeMake(MAXFLOAT, 0.0) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrButton context:nil].size;
        [btnString drawInRect:NSMakeRect(0, (self.frame.size.height - size.height)/2, self.frame.size.width, self.frame.size.height)];
    }
}
@end

//
//  HeadButton.h
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "CustomButton.h"

@interface HeadButton : CustomButton

- (instancetype)initWithTitle:(NSString *)title index:(NSUInteger)index;

@end

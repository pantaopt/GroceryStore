//
//  BlockMacros.h
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#ifndef BlockMacros_h
#define BlockMacros_h

#import <Cocoa/Cocoa.h>

typedef void(^ClickNextButton)(NSInteger idx);

#endif /* BlockMacros_h */

//
//  HeadButton.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HeadButton.h"

@interface HeadButton ()
@end

@implementation HeadButton

- (instancetype)initWithTitle:(NSString *)title index:(NSUInteger)index
{
    self = [super init];
    if (self) {
        NSImageView *idxImage = [NSImageView new];
        idxImage.image = [NSImage imageNamed:[NSString stringWithFormat:@"gray_%lu",index+1]];
        [self addSubview:idxImage];
        [idxImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@10);
            make.height.width.equalTo(@30);
            make.centerY.equalTo(self);
        }];
    }
    return self;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end

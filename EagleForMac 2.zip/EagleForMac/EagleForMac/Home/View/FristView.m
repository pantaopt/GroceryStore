//
//  FristView.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "FristView.h"

@implementation FristView

- (instancetype)initWithFrame:(NSRect)frameRect
{
    self = [super initWithFrame:frameRect];
    if (self) {
        CustomButton *nextBtn = [CustomButton new];
        nextBtn.action = @selector(next);
        nextBtn.target = self;
        [nextBtn setButtonType:NSButtonTypeMomentaryPushIn];
        [nextBtn setTitle:@"下一步"];
        [self addSubview:nextBtn];
        [nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.bottom.equalTo(self).offset(-50);
            make.width.equalTo(@120);
            make.height.equalTo(@30);
        }];
    }
    return self;
}

- (void)next
{
    if (self.block) {
        self.block(1);
    }
}

@end

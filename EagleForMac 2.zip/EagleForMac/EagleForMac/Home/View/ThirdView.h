//
//  ThirdView.h
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ThirdView : CustomView

@property (nonatomic, strong) ClickNextButton block;

@end

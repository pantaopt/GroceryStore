//
//  HomeViewController.m
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HomeViewController.h"
#import "FristView.h"
#import "SecondView.h"
#import "ThirdView.h"
#import "HeadButton.h"

#define kWidth self.view.bounds.size.width
#define kHeight self.view.bounds.size.height
static const CGFloat headItemWidth = 150;
static const CGFloat headHeight = 100;
static const CGFloat logoHeight = 40;

@interface HomeViewController ()

@property (nonatomic, strong) NSScrollView *mainScrollView;
@property (nonatomic, strong) CustomView *headView;

@property (nonatomic, strong) CustomView *mainView;
@property (nonatomic, strong) FristView *fristView;
@property (nonatomic, strong) SecondView *secondView;
@property (nonatomic, strong) ThirdView *thirdView;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubviews];
}

- (void)setupSubviews
{
    // LOGO
    NSText *text = [NSText new];
    text.textColor = [NSColor whiteColor];
    text.string = @"EAGLE";
    text.backgroundColor = [NSColor clearColor];
    text.font = [NSFont boldSystemFontOfSize:22];
    text.editable = NO;
    [self.view addSubview:text];
    [text mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.height.mas_equalTo(logoHeight);
        make.left.equalTo(self.view).offset(20);
        make.top.equalTo(self.view).offset(20);
    }];
    
    [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.height.mas_equalTo(headHeight);
        make.top.equalTo(text.mas_bottom).offset(20);
    }];
    
    NSArray *titleArray = @[@"创建项目", @"选择展现方式", @"选择组件"];
    for (int i = 0; i < 3; i++) {
        HeadButton *headBtn = [[HeadButton alloc] initWithTitle:titleArray[i] index:i];
        headBtn.bgColor = [NSColor clearColor];
        headBtn.tag = 1000 + i;
        headBtn.action = @selector(clickItem:);
        [self.headView addSubview:headBtn];
        [headBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(headItemWidth);
            make.height.equalTo(self.headView);
            make.top.equalTo(self.headView);
            make.left.equalTo(self.headView).mas_equalTo((kWidth - headItemWidth*3)/2 + headItemWidth*i);
        }];
    }
    
    // 主ScrollView
    [self.mainScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.view);
        make.top.equalTo(self.headView.mas_bottom);
    }];
    
    [self.mainView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.left.equalTo(self.mainScrollView);
        make.width.mas_equalTo(kWidth *3);
    }];
    
    [self.fristView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(self.mainView);
        make.width.mas_equalTo(kWidth);
    }];
    [self.secondView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(self.mainView);
        make.left.equalTo(self.fristView.mas_right);
        make.width.mas_equalTo(kWidth);
    }];
    [self.thirdView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(self.mainView);
        make.left.equalTo(self.secondView.mas_right);
        make.width.mas_equalTo(kWidth);
    }];
    
    __weak typeof(self)weakSelf = self;
    self.fristView.block = ^(NSInteger idx) {
        [weakSelf.mainScrollView.contentView scrollToPoint:NSMakePoint(1000 *idx, 0)];
    };
}

- (void)clickItem:(NSButton *)button
{
    NSInteger tag = button.tag - 1000;
    [self.mainScrollView.contentView scrollToPoint:NSMakePoint(1000 *tag, 0)];
}

#pragma mark -- Properties

- (NSScrollView *)mainScrollView
{
    if (!_mainScrollView) {
        _mainScrollView = [NSScrollView new];
        _mainScrollView.hasVerticalScroller = NO;
        _mainScrollView.hasHorizontalScroller = NO;
        _mainScrollView.backgroundColor = [NSColor whiteColor];        
        [_mainScrollView setDocumentView:self.mainView];
        [self.view addSubview:_mainScrollView];
    }
    return _mainScrollView;
}

- (CustomView *)headView
{
    if (!_headView) {
        _headView = [CustomView new];
        [self.view addSubview:_headView];
    }
    return _headView;
}

- (CustomView *)mainView
{
    if (!_mainView) {
        _mainView = [CustomView new];
        [_mainView addSubview:self.fristView];
        [_mainView addSubview:self.secondView];
        [_mainView addSubview:self.thirdView];
    }
    return _mainView;
}

- (FristView *)fristView
{
    if (!_fristView) {
        _fristView = [FristView new];
    }
    return _fristView;
}

- (SecondView *)secondView
{
    if (!_secondView) {
        _secondView = [SecondView new];
    }
    return _secondView;
}

- (ThirdView *)thirdView
{
    if (!_thirdView) {
        _thirdView = [ThirdView new];
    }
    return _thirdView;
}

@end

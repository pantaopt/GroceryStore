#!/bin/bash

function swicth()
{
cd ~/.ssh
ssh-add $1
}

swicth $1

exit 0

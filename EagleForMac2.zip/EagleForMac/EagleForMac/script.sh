#!/bin/bash

function show()
{
cd ~/.ssh
for i in `ls`
do
if [ -d "$i" ]
then
show "$i"
else
echo "$i"
fi
done
}

show

exit 0

//
//  AppDelegate.m
//  EagleForMac
//
//  Created by pantao on 2017/11/17.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (BOOL)applicationShouldHandleReopen:(NSApplication *)theApplication hasVisibleWindows:(BOOL)flag
{
    [theApplication.keyWindow makeKeyAndOrderFront:nil];
    return YES;
}

@end

//
//  SecondView.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "SecondView.h"

@implementation SecondView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [[NSColor blackColor] set];
    NSRectFill(dirtyRect);
    // Drawing code here.
}

@end

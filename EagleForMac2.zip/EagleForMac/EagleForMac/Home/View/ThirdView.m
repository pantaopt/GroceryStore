//
//  ThirdView.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "ThirdView.h"

@implementation ThirdView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [[NSColor greenColor] set];
    NSRectFill(dirtyRect);
    // Drawing code here.
}

@end

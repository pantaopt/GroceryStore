//
//  FristView.m
//  EagleForMac
//
//  Created by pantao on 2017/11/23.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "FristView.h"

@interface NextButton: NSButton
@end

@implementation NextButton

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [[NSColor orangeColor] set];
    NSRectFill(dirtyRect);
    // Drawing code here.
}

@end

@implementation FristView

- (instancetype)initWithFrame:(NSRect)frameRect
{
    self = [super initWithFrame:frameRect];
    if (self) {
        NextButton *nextBtn = [NextButton buttonWithTitle:@"next" target:self action:@selector(next)];
        [self addSubview:nextBtn];
    }
    return self;
}

- (void)next
{
    
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    [[NSColor brownColor] set];
    NSRectFill(dirtyRect);
    // Drawing code here.
}

@end

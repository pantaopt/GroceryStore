//
//  HomeViewController.h
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HomeViewController : NSViewController

@end

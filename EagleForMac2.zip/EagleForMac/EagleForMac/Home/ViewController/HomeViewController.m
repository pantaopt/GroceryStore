//
//  HomeViewController.m
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HomeViewController.h"
#import "Masonry.h"
#import "FristView.h"
#import "SecondView.h"
#import "ThirdView.h"

#define kWidth self.view.bounds.size.width
#define kHeight self.view.bounds.size.height
static const CGFloat logoHeight = 40;

@interface HomeViewController ()

@property (nonatomic, strong) NSScrollView *mainScrollView;
@property (nonatomic, strong) NSView *mainView;

@property (nonatomic, strong) FristView *fristView;
@property (nonatomic, strong) SecondView *secondView;
@property (nonatomic, strong) ThirdView *thirdView;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubviews];
}

- (void)setupSubviews
{
    // LOGO
    NSText *text = [NSText new];
    text.textColor = [NSColor whiteColor];
    text.string = @"EAGLE";
    text.backgroundColor = [NSColor clearColor];
    text.font = [NSFont boldSystemFontOfSize:22];
    text.editable = NO;
    [self.view addSubview:text];
    [text mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.height.mas_equalTo(logoHeight);
        make.left.equalTo(self.view).offset(20);
        make.top.equalTo(self.view).offset(20);
    }];
    
    // 主ScrollView
    [self.mainScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.view);
        make.top.equalTo(text.mas_bottom).offset(20);
    }];
    
    self.fristView.layer.backgroundColor = [NSColor blackColor].CGColor;
    self.secondView.layer.backgroundColor = [NSColor redColor].CGColor;
    self.thirdView.layer.backgroundColor = [NSColor greenColor].CGColor;
}

#pragma mark -- Properties

- (NSScrollView *)mainScrollView
{
    if (!_mainScrollView) {
        _mainScrollView = [NSScrollView new];
        _mainScrollView.hasVerticalScroller = NO;
        _mainScrollView.hasHorizontalScroller = YES;
        _mainScrollView.backgroundColor = [NSColor whiteColor];        
        [_mainScrollView setDocumentView:self.mainView];
        [self.view addSubview:_mainScrollView];
    }
    return _mainScrollView;
}

- (NSView *)mainView
{
    if (!_mainView) {
        _mainView = [[NSView alloc] initWithFrame:CGRectMake(0, 0, kWidth*3, kHeight - logoHeight)];
        [_mainView addSubview:self.fristView];
        [_mainView addSubview:self.secondView];
        [_mainView addSubview:self.thirdView];
    }
    return _mainView;
}

- (FristView *)fristView
{
    if (!_fristView) {
        _fristView = [[FristView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight - logoHeight)];
    }
    return _fristView;
}

- (SecondView *)secondView
{
    if (!_secondView) {
        _secondView = [[SecondView alloc] initWithFrame:CGRectMake(kWidth, 0, kWidth, kHeight - logoHeight)];
    }
    return _secondView;
}

- (ThirdView *)thirdView
{
    if (!_thirdView) {
        _thirdView = [[ThirdView alloc] initWithFrame:CGRectMake(kWidth *2, 0, kWidth, kHeight - logoHeight)];
    }
    return _thirdView;
}

@end

//
//  HomeViewController.m
//  EagleForMac
//
//  Created by pantao on 2017/11/20.
//  Copyright © 2017年 linkage. All rights reserved.
//

#import "HomeViewController.h"
#import "Masonry.h"
#import "NetWorking.h"
#import "STPrivilegedTask.h"

@interface HomeViewController ()

@property(nonatomic, strong) NSStatusItem * statusItem;
@property(nonatomic, assign) BOOL fristSh;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _fristSh = YES;
//    [self loadFilesWithSTP];
    [self ejectShell:@"/bin/sh script.sh"];
    [self setupSubviews];
//    [self requestData];
}

- (void)setupStatusWithSshKeys:(NSArray *)sshKeys
{
    self.statusItem        = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    self.statusItem.title  = @"";
    self.statusItem.image  = [NSImage imageNamed:@"BTSearcherIcon"];
    self.statusItem.target = self;
    NSMenu * menu = [[NSMenu alloc] init];
    if (sshKeys.count == 0) {
        //    self.statusItem.action = @selector(openWindow:);
        [menu addItemWithTitle:@"未设置sshKey" action:nil keyEquivalent:@""];
    }else {
        for (NSString *sshKey in sshKeys) {
            NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:sshKey action:@selector(toggleNotifications:) keyEquivalent:@""];
            [item setTarget:self];
            [menu addItem:item];
        }
    }
    [menu addItem:[NSMenuItem separatorItem]];
    self.statusItem.menu = menu;
}

- (void)toggleNotifications:(NSMenuItem *)item
{
    NSString *title = item.title;
    [self ejectShell:[NSString stringWithFormat:@"/bin/sh sshKeySwitch.sh %@",title]];
}

- (void)ejectShell:(NSString *)cmd
{
    NSTask *task = [[NSTask alloc] init];
    
    NSMutableArray *components = [[cmd componentsSeparatedByString:@" "] mutableCopy];
    task.launchPath = components[0];
    [components removeObjectAtIndex:0];
    task.arguments = components;
    task.currentDirectoryPath = [[NSBundle  mainBundle] resourcePath];
    
    NSPipe *outputPipe = [NSPipe pipe];
    [task setStandardOutput:outputPipe];
    [task setStandardError:outputPipe];
    NSFileHandle *readHandle = [outputPipe fileHandleForReading];
    
    [task launch];
    [task waitUntilExit];
    NSData *outputData = [readHandle readDataToEndOfFile];
    NSString *outputString = [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
//    NSString *exitStr = [NSString stringWithFormat:@"Exit status: %d", task.terminationStatus];
    
    NSLog(@">>>>>>>>>>>>outputString: %@",outputString);
//    NSLog(@">>>>>>>>>>>>exitStr: %@",exitStr);
    if (!_fristSh) {
        return;
    }
    _fristSh = NO;
    NSMutableArray *sshKeys = [NSMutableArray array];
    if (task.terminationStatus == 0) {
        NSArray *temp_sshKeys = [outputString componentsSeparatedByString:@"\n"];
        if (temp_sshKeys.count > 0) {
            for (NSString *sshKey in temp_sshKeys) {
                if ([sshKey rangeOfString:@"host"].location != NSNotFound || [sshKey rangeOfString:@".pub"].location != NSNotFound) {
                    continue;
                }
                [sshKeys addObject:sshKey];
            }
        }
    }
    [self setupStatusWithSshKeys:sshKeys];
}

- (void)loadFilesWithSTP
{
    STPrivilegedTask *privilegedTask = [[STPrivilegedTask alloc] init];
    
    NSMutableArray *components = [[@"/bin/sh script.sh" componentsSeparatedByString:@" "] mutableCopy];
    NSString *launchPath = components[0];
    [components removeObjectAtIndex:0];
    
    [privilegedTask setLaunchPath:launchPath];
    [privilegedTask setArguments:components];
    [privilegedTask setCurrentDirectoryPath:[[NSBundle mainBundle] resourcePath]];
    
    //set it off
    OSStatus err = [privilegedTask launch];
    if (err != errAuthorizationSuccess) {
        if (err == errAuthorizationCanceled) {
            NSLog(@"User cancelled");
            return;
        }  else {
            NSLog(@"Something went wrong: %d", (int)err);
            // For error codes, see http://www.opensource.apple.com/source/libsecurity_authorization/libsecurity_authorization-36329/lib/Authorization.h
        }
    }
    
    [privilegedTask waitUntilExit];
    
    NSFileHandle *readHandle = [privilegedTask outputFileHandle];
    NSData *outputData = [readHandle readDataToEndOfFile];
    NSString *outputString = [[NSString alloc] initWithData:outputData encoding:NSUTF8StringEncoding];
    
    NSString *exitStr = [NSString stringWithFormat:@"Exit status: %d", privilegedTask.terminationStatus];
    
    NSLog(@">>>>>>>>>>>>outputString: %@",outputString);
    NSLog(@">>>>>>>>>>>>exitStr: %@",exitStr);
}

- (void)setupSubviews
{
    NSText *text = [NSText new];
    text.textColor = [NSColor whiteColor];
    text.string = @"EAGLE";
    text.backgroundColor = [NSColor clearColor];
    text.font = [NSFont boldSystemFontOfSize:22];
    text.editable = NO;
    [self.view addSubview:text];
    [text mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@100);
        make.height.equalTo(@80);
        make.left.equalTo(self.view).offset(20);
        make.top.equalTo(self.view).offset(20);
    }];
}

- (void)requestData
{
    [[NetWorking sharedManagerWithBaseUrl:nil] requestWithMethod:GET Url:@"v3/projects?private_token=-9Pcd7xyXBcsSCP4k7Bv/" Parameter:nil DownloadProgress:nil SuccessBlock:^(id responseBody) {
        NSLog(@"responseBody: %@",responseBody);
    } FailureBlock:^(NSDictionary *error) {
        NSLog(@"error: %@",error);
    }];
}

@end

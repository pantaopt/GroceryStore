#!/usr/bin/perl
$ENV{"PATH"} = "/usr/bin";
print `/bin/bash script.sh`;

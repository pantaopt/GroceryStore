//
//  ViewController1.h
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController1 : UIViewController

@end

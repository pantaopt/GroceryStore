//
//  ViewController1.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "ViewController1.h"
#import "LKG.h"

@interface ViewController1 (){
    FMDatabase *_database;
}

@end

@implementation ViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor purpleColor];
    
    UIBarButtonItem *minus = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemStop target:self action:@selector(minus_data)];
    UIBarButtonItem *add = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add_data)];
    
    self.navigationItem.rightBarButtonItems = @[minus, add];
    
    [self FMDB_sqlite];
}

/**
 删除一条数据
 */
- (void)minus_data{
    if (![_database open]) return;
    if ([_database executeUpdate:@"delete from test_table where num = 26;"]) {
       [self queryTable];
        LZToast *toast = [[LZToast alloc] initWithText:@"删除数据成功"];
        [toast showInView:self.view showType:LZToastShowTypeBottom];
    }else{
        LZToast *toast = [[LZToast alloc] initWithText:@"删除数据失败"];
        [toast showInView:self.view showType:LZToastShowTypeBottom];
    }
}

/**
 添加数据
 */
- (void)add_data{
    if (![_database open]) return;
    if ([_database executeUpdate:@"insert into test_table(num,name,sex) values(27,'pantao','man');"]) {
        [self queryTable];
        LZToast *toast = [[LZToast alloc] initWithText:@"添加数据成功"];
        [toast showInView:self.view showType:LZToastShowTypeBottom];
    }else{
        LZToast *toast = [[LZToast alloc] initWithText:@"添加数据失败"];
        [toast showInView:self.view showType:LZToastShowTypeBottom];
    }
}

/**
 创建数据库、表
 */
- (void)FMDB_sqlite{
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject;
    NSString *filePath = [path stringByAppendingPathComponent:@"FMDB.db"];
    _database = [FMDatabase databaseWithPath:filePath];
    
    if ([_database open]) {
        NSLog(@"开启了");
        NSString *sqlStr = @"CREATE TABLE IF NOT EXISTS test_table(num integer,name varchar(7),sex varchar(1),primary key(num));";
        BOOL res = [_database executeUpdate:sqlStr];
        if (res)
        {
            NSLog(@"创建表成功");
        }
    }else{
        NSLog(@"开启失败");
    }
    
    [self queryTable];
}

/**
 查询表
 */
- (void)queryTable{
    //执行查询SQL语句，返回查询结果
    FMResultSet *result = [_database executeQuery:@"select * from test_table"];
    NSMutableArray *array = [NSMutableArray array];
    //获取查询结果的下一个记录
    while ([result next]) {
        //根据字段名，获取记录的值，存储到字典中
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        int num  = [result intForColumn:@"num"];
        NSString *name = [result stringForColumn:@"name"];
        NSString *sex  = [result stringForColumn:@"sex"];
        dict[@"num"] = @(num);
        dict[@"name"] = name;
        dict[@"sex"] = sex;
        //把字典添加进数组中
        [array addObject:dict];
    }
    
    NSLog(@"查询数据库结果：%@",array);
}

/**
 删除表
 */
- (void)deleteTable{
    [_database executeUpdate:@"DROP TABLE IF EXISTS test_table"];
}

@end

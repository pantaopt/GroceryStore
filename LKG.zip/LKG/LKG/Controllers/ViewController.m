//
//  ViewController.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "ViewController.h"
#import "ViewController1.h"
#import "Component1.h"
#import "Component2.h"
#import "Component3.h"
#import "Component4.h"
#import "Component5.h"
#import "LKG.h"

@interface ViewController (){
    float _kScreenWidth;
    float _kScreenHeight;
}

@end

@implementation ViewController


/**
  ·默认使用LKG框架
 
  ·不想使用LKG框架，或者已有UIViewController已存在业务UI，可重写loadView方法
 e.g:    - (void)loadView{
           self.view = [UIView new];
        }
 */

/**
 · https://facebook.github.io/yoga/docs/learn-more/
 ·在LKG框架中，UIKit支持FlexBox布局
 ·yoga.isEnabled为YES时开启FB布局，NO关闭FB布局
 ·是否开启FB布局可以由开发者灵活设置，即可以在同一父视图，部分子视图开启FB布局，部分子视图关闭FB布局，但需要注意的是UI显示
 ·注意： 虽然使用了FB布局，但是是拿不到组件(控件)的frame的，因此如果需要使用FB，建议子组件(控件)都使用FB。
 ·若父视图使用了FB，子视图想要自身不收父视图的约束(将自身剔除父视图的约束树)，e.g：子视图.yoga.isIncludedInLayout = NO;
 ·若FB约束树内有UILabel、UITextView、UIButton等具有text属性的控件时，当text有值时，FB会进行自动拉伸以进行文字适配
    --解决办法是具有text属性的控件给其指定size
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _kScreenWidth = [UIScreen mainScreen].bounds.size.width;
    _kScreenHeight = [UIScreen mainScreen].bounds.size.height;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"下一页" style:UIBarButtonItemStylePlain target:self action:@selector(click)];
    
/****************************************************************************************************/
//    Component1 *bottomView = [[Component1 alloc] initWithSuperComponent:self.selfView];
//    bottomView.backgroundColor = [UIColor redColor];
//    bottomView.yoga.flexDirection = YGFlexDirectionColumn;
//    bottomView.yoga.top = 64;
//    bottomView.yoga.height =  _kScreenHeight - 64 - 50;

    self.selfView.backgroundColor = [UIColor redColor];
/****************************************************************************************************/
    Component1 *C1 = [[Component1 alloc] initWithSuperComponent:self.selfView];
    C1.yoga.flexGrow = 1;
//    C1.yoga.top = 64;
//    C1.yoga.margin = 10;
    C1.backgroundColor = [UIColor colorWithRed:0.97f green:0.38f blue:0.38f alpha:1.00f];
    C1.yoga.flexDirection = YGFlexDirectionRow;
    
    Component2 *C2 = [[Component2 alloc] initWithSuperComponent:C1];
    C2.backgroundColor = [UIColor colorWithRed:0.15f green:0.17f blue:0.20f alpha:1.00f];
    C2.yoga.flexGrow = 1;
    
    Component3 *C3 = [[Component3 alloc] initWithSuperComponent:C1];
    C3.backgroundColor = [UIColor colorWithRed:1.00f green:0.75f blue:0.00f alpha:1.00f];
    C3.yoga.flexGrow = 1;
    
    UILabel *L1 = [[UILabel alloc] init];
    L1.text = @"组件1";
    L1.yoga.isEnabled = YES;
    L1.yoga.isIncludedInLayout = NO;
    L1.frame = CGRectMake(0, 0, _kScreenWidth - 20, (_kScreenHeight - 64 - 50 - 40)/2);
    L1.textColor = [UIColor blackColor];
    L1.font = [UIFont systemFontOfSize:15];
    L1.textAlignment = NSTextAlignmentCenter;
    [C1 addSubview:L1];
    
/****************************************************************************************************/
    Component4 *C4 = [[Component4 alloc] initWithSuperComponent:self.selfView];
    C4.yoga.flexGrow = 1;
    C4.yoga.margin = 10;
//    C4.yoga.top = 64;
    C4.backgroundColor = [UIColor colorWithRed:0.97f green:0.38f blue:0.38f alpha:1.00f];
    C4.yoga.flexDirection = YGFlexDirectionColumn;
//    C4.yoga.justifyContent = YGJustifyFlexStart;
//    C4.yoga.flexWrap = YGWrapWrap;
    
    UIView *V4 = [[UIView alloc] init];
    V4.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.3];
    V4.yoga.isEnabled = YES;
    V4.yoga.flexGrow = 1;
    [C4 addSubview:V4];
    
    UILabel *L4 = [[UILabel alloc] init];
    L4.text = @"组件4";
    L4.yoga.isEnabled = YES;
    L4.yoga.isIncludedInLayout = NO;
    L4.frame = CGRectMake(0, 0, _kScreenWidth - 20, (_kScreenHeight - 64 - 50 - 40)/2);
    L4.textColor = [UIColor blackColor];
    L4.font = [UIFont systemFontOfSize:15];
    L4.textAlignment = NSTextAlignmentCenter;
    [V4 addSubview:L4];
    
    Component5 *C5 = [[Component5 alloc] initWithSuperComponent:C4];
    C5.backgroundColor = [UIColor colorWithRed:0.06f green:0.68f blue:1.00f alpha:1.00f];
    C5.yoga.isIncludedInLayout = NO;
    C5.frame = CGRectMake(0, 0, _kScreenWidth - 20, 50);
    
/****************************************************************************************************/
    UILabel *L = [[UILabel alloc] initWithFrame:CGRectMake(0, _kScreenHeight - 50, _kScreenWidth, 50)];
    L.yoga.isEnabled = YES;
    L.yoga.isIncludedInLayout = NO;
    L.text = @"我是add在self.view上的UIView";
    L.textColor = [UIColor blackColor];
    L.font = [UIFont systemFontOfSize:15];
    L.textAlignment = NSTextAlignmentCenter;
    L.backgroundColor = [UIColor colorWithRed:0.02f green:0.75f blue:0.01f alpha:1.00f];
    [self.view addSubview:L];

}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)click{
    ViewController1 *vc1 = [[ViewController1 alloc] init];
    [self.navigationController pushViewController:vc1 animated:YES];
}

@end

//
//  LZDB.m
//  LKG
//
//  Created by 潘涛 on 2017/3/27.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "LZDB.h"

@implementation LZDB

+ (instancetype)dbWithPath:(NSString *)path{
    LZDB *lzdb = [[LZDB alloc] init];
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:path];
    lzdb.db = [FMDatabase databaseWithPath:filePath];
    return lzdb;
}

- (void)createTable:(NSString *)tableName{
    if ([self.db open]) {
        NSLog(@"开启了");
        BOOL res = [self.db executeUpdate:@"CREATE TABLE IF NOT EXISTS ?(num integer,name varchar(7),sex varchar(1),primary key(num));",tableName];
        if (res)
        {
            NSLog(@"创建表成功");
        }
    }else{
        NSLog(@"开启失败");
    }
}

- (void)deleteTable:(NSString *)tableName{
    [self.db executeUpdate:@"DROP TABLE IF EXISTS ?",tableName];
}

@end

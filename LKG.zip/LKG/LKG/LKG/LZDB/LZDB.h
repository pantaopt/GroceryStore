//
//  LZDB.h
//  LKG
//
//  Created by 潘涛 on 2017/3/27.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"// sqlite数据库第三方库FMDB

@interface LZDB : NSObject

@property (nonatomic, strong) FMDatabase *db;

/**
 创建数据库

 @param path db名称
 1. 如果该路径下已经存在该数据库，直接获取该数据库;
 2. 如果不存在就创建一个新的数据库;
 3. 如果传@""，会在临时目录创建一个空的数据库，当数据库关闭时，数据库文件也被删除;
 4. 如果传nil，会在内存中临时创建一个空的数据库，当数据库关闭时，数据库文件也被删除;
 */
+ (instancetype)dbWithPath:(NSString *)path;

/**
 创建表

 @param tableName 表名
 */
- (void)createTable:(NSString *)tableName;

/**
 删除表

 @param tableName 表名
 */
- (void)deleteTable:(NSString *)tableName;

@end

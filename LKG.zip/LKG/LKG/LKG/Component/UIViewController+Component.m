//
//  UIViewController+Component.m
//  LKG-SDK
//
//  Created by 潘涛 on 2017/3/13.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIViewController+Component.h"
#import <objc/runtime.h>

#ifdef DEBUG  //调试阶段
#define LKGLog(...)  NSLog(__VA_ARGS__)
#else //发布阶段
#define LKGLog(...)
#endif

@implementation UIViewController (Component)

- (Component *)selfView{
    return objc_getAssociatedObject(self, @selector(selfView));
    
}

- (void)setSelfView:(Component *)selfView{
//    selfView.backgroundColor = [UIColor redColor];
//    selfView.yoga.flexDirection = YGFlexDirectionColumn;
//    selfView.yoga.top = 64;
//    selfView.yoga.height =  [UIScreen mainScreen].bounds.size.height - 64;
    objc_setAssociatedObject(self, @selector(selfView), selfView, OBJC_ASSOCIATION_RETAIN);
}

+ (void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        method_exchangeImplementations(class_getInstanceMethod(self, @selector(loadView)), class_getInstanceMethod(self, @selector(componentLoadView)));
        
        method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewDidLoad)), class_getInstanceMethod(self, @selector(componentViewDidLoad)));

        method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewWillAppear:)), class_getInstanceMethod(self, @selector(componentViewWillAppear:)));
        
        method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewDidAppear:)), class_getInstanceMethod(self, @selector(componentViewDidAppear:)));
        
        method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewWillDisappear:)), class_getInstanceMethod(self, @selector(componentViewWillDisappear:)));
        
        method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewDidDisappear:)), class_getInstanceMethod(self, @selector(componentViewDidDisappear:)));
    });
}

- (void)componentLoadView{
    self.view = [UIView new];
    self.selfView = [[Component alloc] init];
    self.selfView.yoga.isEnabled = YES;
    self.selfView.yoga.flexDirection = YGFlexDirectionColumn;
    self.selfView.yoga.justifyContent = YGJustifyFlexStart;
    self.selfView.backgroundColor = [UIColor whiteColor];
    self.view = self.selfView;
}

// 组件初始化
- (void)componentViewDidLoad{
    [self.selfView viewDidLoad];
    [self.selfView.yoga applyLayoutPreservingOrigin:NO];
}

// 组件将要展示
- (void)componentViewWillAppear:(BOOL)animated{
    [self.selfView viewWillAppear:animated];
    [self.selfView.yoga applyLayoutPreservingOrigin:NO];
}

// 组件已经展示
- (void)componentViewDidAppear:(BOOL)animated{
    [self.selfView viewDidAppear:animated];
}

// 组件将要消失
- (void)componentViewWillDisappear:(BOOL)animated{
    [self.selfView viewWillDisappear:animated];
}

// 组件已经消失
- (void)componentViewDidDisappear:(BOOL)animated{
    [self.selfView viewDidDisappear:animated];
}

@end

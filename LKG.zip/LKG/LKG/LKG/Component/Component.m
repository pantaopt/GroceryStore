//
//  Component.m
//  OC's component
//
//  Created by 潘涛 on 2017/3/10.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component.h"
#import <objc/runtime.h>

typedef IMP *IMPPointer;

static void MethodSwizzle(id self, SEL _cmd, id arg1);
static void (*MethodOriginal)(id self, SEL _cmd, id arg1);

static void MethodSwizzle(id self, SEL _cmd, id arg1)
{
    MethodOriginal(self, _cmd, arg1);
}

BOOL class_swizzleMethodAndStore(Class class, SEL original, IMP replacement, IMPPointer store)
{
    IMP imp = NULL;
    Method method = class_getInstanceMethod(class, original);
    if (method) {
        const char *type = method_getTypeEncoding(method);
        imp = class_replaceMethod(class, original, replacement, type);
        if (!imp) {
            imp = method_getImplementation(method);
        }
    }
    if (imp && store) {
        *store = imp;
    }
    return (imp != NULL);
}

@interface Component ()

@property (nonatomic, strong) NSMutableDictionary *componentCache;

@end

@implementation Component

+ (BOOL)swizzle:(SEL)original with:(IMP)replacement store:(IMPPointer)store {
    return class_swizzleMethodAndStore(self, original, replacement, store);
}

+ (void)load
{
}

- (instancetype)init{
    self = [super initWithFrame:CGRectZero];
    if (self) {
        self.yoga.isEnabled = YES;
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.yoga.isEnabled = YES;
    }
    return self;
}

#pragma mark -- 注册component
- (instancetype)initWithSuperComponent:(Component *)component{
        NSAssert([component isKindOfClass:[Component class]] , @"父视图必须是继承自UIView");
//    NSAssert([component isMemberOfClass:[Component class]] , @"父视图必须是继承自UIView");
    self = [super initWithFrame:CGRectZero];
    if (self) {
        self.yoga.isEnabled = YES;
        if (component) {
            NSString *componentName = NSStringFromClass([self class]);
            [component.componentCache setObject:self forKey:componentName];
//            if (component.subComponent.count == 0) {
//                [component.subComponent addObject:self];
//            }else {
//                [component.subComponent insertObject:self atIndex:0];
//            }
            [component addSubview:self];
//            [self viewDidLoad]; // 初始化完成并加载在父组件视图上
        }
    }
    return self;
}

#pragma mark -- Component的生命周期
- (void)viewDidLoad{
//    for (Component *component in self.subComponent) {
//        [component viewDidLoad];
//    }
    NSMutableArray *tempArray = (NSMutableArray *)[[self.componentCache.allKeys reverseObjectEnumerator] allObjects];
    for (NSString *componentName in tempArray) {
        Component *component = (Component *)[self.componentCache objectForKey:componentName];
        SEL action = NSSelectorFromString(@"viewDidLoad");
        if ([component respondsToSelector:action]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [component performSelector:action withObject:nil];
#pragma clang diagnostic pop
        }
    }
}

- (void)viewWillAppear:(BOOL)animated{
//    for (Component *component in self.subComponent) {
//        [component viewWillAppear:animated];
//    }
    NSMutableArray *tempArray = (NSMutableArray *)[[self.componentCache.allKeys reverseObjectEnumerator] allObjects];
    for (NSString *componentName in tempArray) {
        Component *component = (Component *)[self.componentCache objectForKey:componentName];
        SEL action = NSSelectorFromString(@"viewWillAppear:");
        if ([component respondsToSelector:action]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [component performSelector:action withObject:nil];
#pragma clang diagnostic pop
        }
    }
}

- (void)viewDidAppear:(BOOL)animated{
//    for (Component *component in self.subComponent) {
//        [component viewDidAppear:animated];
//    }
    NSMutableArray *tempArray = (NSMutableArray *)[[self.componentCache.allKeys reverseObjectEnumerator] allObjects];
    for (NSString *componentName in tempArray) {
        Component *component = (Component *)[self.componentCache objectForKey:componentName];
        SEL action = NSSelectorFromString(@"viewDidAppear:");
        if ([component respondsToSelector:action]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [component performSelector:action withObject:nil];
#pragma clang diagnostic pop
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated{
//    for (Component *component in self.subComponent) {
//        [component viewWillDisappear:animated];
//    }
    NSMutableArray *tempArray = (NSMutableArray *)[[self.componentCache.allKeys reverseObjectEnumerator] allObjects];
    for (NSString *componentName in tempArray) {
        Component *component = (Component *)[self.componentCache objectForKey:componentName];
        SEL action = NSSelectorFromString(@"viewWillDisappear:");
        if ([component respondsToSelector:action]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [component performSelector:action withObject:nil];
#pragma clang diagnostic pop
        }
    }
}

- (void)viewDidDisappear:(BOOL)animated{
//    for (Component *component in self.subComponent) {
//        [component viewDidDisappear:animated];
//    }
    NSMutableArray *tempArray = (NSMutableArray *)[[self.componentCache.allKeys reverseObjectEnumerator] allObjects];
    for (NSString *componentName in tempArray) {
        Component *component = (Component *)[self.componentCache objectForKey:componentName];
        SEL action = NSSelectorFromString(@"viewDidDisappear:");
        if ([component respondsToSelector:action]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [component performSelector:action withObject:nil];
#pragma clang diagnostic pop
        }
    }
}

- (NSMutableDictionary *)componentCache
{
    if (!_componentCache) {
        _componentCache = [NSMutableDictionary dictionary];
    }
    return _componentCache;
}

- (NSMutableArray *)subComponent{
    if (!_subComponent) {
        _subComponent = [NSMutableArray array];
    }
    return _subComponent;
}

#pragma mark -- 请求网络
-(void)requestWithMethod:(HTTPMethod)method Url:(NSString *)url Parameter:(id)paramer DownloadProgress:(DownloadProgress)progress SuccessBlock:(SuccessBlock)successblock FailureBlock:(FailureBlock)failureblock{
    [[NetWorking sharedManagerWithBaseUrl:nil] requestWithMethod:method Url:url Parameter:paramer DownloadProgress:^(NSProgress *downloadProgress) {
        progress(downloadProgress);
    } SuccessBlock:^(id responseBody) {
        successblock(responseBody);
    } FailureBlock:^(NSDictionary *error) {
        failureblock(error);
    }];
}

@end

//
//  UIViewController+Component.h
//  LKG-SDK
//
//  Created by 潘涛 on 2017/3/13.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Component.h"

@interface UIViewController (Component)

@property (nonatomic, strong) Component *selfView;

@end

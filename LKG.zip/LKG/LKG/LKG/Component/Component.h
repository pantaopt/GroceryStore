//
//  Component.h
//  OC's component
//
//  Created by 潘涛 on 2017/3/10.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Yoga.h"// flexbox布局
#import "UIView+LZView.h"// 数据双向绑定
#import "NetWorking.h"// 网络请求

typedef NS_ENUM(NSUInteger, Flex) {
    // 纵向排列
    cloum  = 0,
    // 横向排列
    row
};

@interface Component : UIView

@property (nonatomic, strong) NSMutableArray *subComponent;

@property (nonatomic, strong) NSMutableDictionary *props;

@property (nonatomic, assign) Flex flex;

#pragma mark -- 请求网络
-(void)requestWithMethod:(HTTPMethod)method Url:(NSString *)url Parameter:(id)paramer DownloadProgress:(DownloadProgress)progress SuccessBlock:(SuccessBlock)successblock FailureBlock:(FailureBlock)failureblock;

#pragma mark -- 注册component
- (instancetype)initWithSuperComponent:(Component *)component;

#pragma mark -- Component的生命周期
- (void)viewDidLoad;

- (void)viewWillAppear:(BOOL)animated;

- (void)viewDidAppear:(BOOL)animated;

- (void)viewWillDisappear:(BOOL)animated;

- (void)viewDidDisappear:(BOOL)animated;

@end

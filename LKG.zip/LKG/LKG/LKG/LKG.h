//
//  LKG.h
//  LKG-SDK
//
//  Created by 潘涛 on 2017/3/13.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LZUIKit.
//FOUNDATION_EXPORT double LZUIKitVersionNumber;

//! Project version string for LZUIKit.
//FOUNDATION_EXPORT const unsigned char LZUIKitVersionString[];

#ifdef DEBUG  //调试阶段
#define LKGLog(...)  NSLog(__VA_ARGS__)
#else //发布阶段
#define LKGLog(...)
#endif

#import "LZUIKit.h"// UI扩展
#import "Component.h"// 组件
//#import "UIViewController+LZBaseVC.h"// UIViewController类别扩展(目的是给组件component提供生命周期)
#import "UIView+Yoga.h"// flexbox布局
#import "NetWorking.h" // 网络请求
#import "UIViewController+Component.h"
#import "LZDB.h" // 将FMDB进行再封装，使其易用
#import "LZToast.h" // 类似安卓的提示弹框

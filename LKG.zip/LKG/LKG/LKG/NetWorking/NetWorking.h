//
//  NetWorking.h
//  LKG-SDK
//
//  Created by 潘涛 on 2017/3/13.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

typedef NS_ENUM(NSUInteger, HTTPMethod) {
    /*!
     GET请求
     */
    GET,
    
    /*!
     POST请求
     */
    POST
};

typedef void(^DownloadProgress)(NSProgress * downloadProgress);

typedef void(^SuccessBlock)(id responseBody);

typedef void(^FailureBlock)(NSDictionary *error);

@interface NetWorking : AFHTTPSessionManager

//封装网络单例方法
//
//baseUrl==nil:使用绝对路径请求网络数据
//baseUrl!=nil:使用相对路径请求网络数据
//
+ (instancetype)sharedManagerWithBaseUrl:(NSString *)URLString;

- (void)requestWithMethod:(HTTPMethod)method Url:(NSString *)url Parameter:(id)paramer DownloadProgress:(DownloadProgress)progress SuccessBlock:(SuccessBlock)successblock FailureBlock:(FailureBlock)failureblock;

@end

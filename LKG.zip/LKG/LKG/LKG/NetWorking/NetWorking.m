//
//  NetWorking.m
//  LKG-SDK
//
//  Created by 潘涛 on 2017/3/13.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "NetWorking.h"

@implementation NetWorking

+ (instancetype)sharedManagerWithBaseUrl:(NSString *)URLString {
    static NetWorking *manager=nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        // baseURL 的目的，就是让后续的网络访问直接使用 相对路径即可，baseURL 的路径一定要有 / 结尾
        NSURL *baseURL = [NSURL URLWithString:URLString];
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        manager = [[self alloc] initWithBaseURL:baseURL sessionConfiguration:config];
        
        // 修改 解析数据格式 能够接受的内容类型 － 官方推荐的做法，民间做法：直接修改 AFN 的源代码
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",
                                                             @"text/json",
                                                             @"text/javascript",
                                                             @"text/html",
                                                             nil];
    });
    return manager;
}

- (void)requestWithMethod:(HTTPMethod)method Url:(NSString *)url Parameter:(id)paramer DownloadProgress:(DownloadProgress)progress SuccessBlock:(SuccessBlock)successblock FailureBlock:(FailureBlock)failureblock{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    NSString *urlStr = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
#pragma clang diagnostic pop
    switch (method) {
        case GET:{
            [self GET:urlStr parameters:paramer progress:^(NSProgress * _Nonnull downloadProgress) {
                progress(downloadProgress);
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                successblock(responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failureblock(error.userInfo);
            }];
            break;
        }
        case POST:{
            [self POST:urlStr parameters:paramer progress:^(NSProgress * _Nonnull downloadProgress) {
                progress(downloadProgress);
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                successblock(responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failureblock(error.userInfo);
            }];
            break;
        }
        default:
            break;
    }
}

@end

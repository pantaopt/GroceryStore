//
//  LZToast.h
//  LKG
//
//  Created by 潘涛 on 2017/3/27.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, LZToastShowType)
{
    LZToastShowTypeTop,
    LZToastShowTypeCenter,
    LZToastShowTypeBottom
};

@interface LZToast : UILabel<CAAnimationDelegate>

@property (nonatomic, assign) CFTimeInterval forwardAnimationDuration;
@property (nonatomic, assign) CFTimeInterval backwardAnimationDuration;
@property (nonatomic, assign) UIEdgeInsets   textInsets;
@property (nonatomic, assign) CGFloat        maxWidth;

+ (id)toastWithText:(NSString *)text;

- (id)initWithText:(NSString *)text;
- (void)showInView:(UIView *)view;    //Default is DSToastShowTypeBottom
- (void)showInView:(UIView *)view showType:(LZToastShowType)type;

@end

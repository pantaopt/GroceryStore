//
//  UIButton+LZButton.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/8.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIButton+LZButton.h"
#import <objc/runtime.h>

@implementation UIButton (LZButton)

- (void)lz_buttonForControlEvents:(UIControlEvents)controlEvents block:(void (^)(id x))lz_ButtonBlock{
    [[self rac_signalForControlEvents:controlEvents]
     subscribeNext:^(id x) {
         lz_ButtonBlock(x);
     }];
}


@end

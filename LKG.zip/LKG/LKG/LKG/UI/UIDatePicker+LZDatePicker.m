//
//  UIDatePicker+LZDatePicker.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/9.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIDatePicker+LZDatePicker.h"

@implementation UIDatePicker (LZDatePicker)

- (void)lz_datePickerWithNilValue:(NSDate *)nilValue Block:(void (^)(id x))lz_DatePickerBlock{
    [[self rac_newDateChannelWithNilValue:nilValue] subscribeNext:^(id x) {
        lz_DatePickerBlock(x);
    }];
}

@end

//
//  UIView+LZView.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIView+LZView.h"

@implementation UIView (LZView)

- (void)LZ_bind_UIKit:(id)UIKit KeyPath:(id)keyPath Model:(NSObject *)model Property:(id)property
{
    if ([UIKit isKindOfClass:[UILabel class]] || [UIKit isKindOfClass:[UIButton class]])// UILabel、UIButton
    {
        [[RACKVOChannel alloc] initWithTarget:UIKit keyPath:keyPath nilValue:nil][@"followingTerminal"] = [[RACKVOChannel alloc] initWithTarget:model keyPath:property nilValue:nil][@"followingTerminal"];
    }
    else if ([UIKit isKindOfClass:[UITextField class]])// UITextField
    {
        UITextField *textField = (UITextField *)UIKit;
        RACChannelTerminal *modelTerminal = [[RACKVOChannel alloc] initWithTarget:model keyPath:property nilValue:nil][@"followingTerminal"];
        RACSubscriptingAssignmentTrampoline *subscriptingAssignmentTrampoline = [[RACSubscriptingAssignmentTrampoline alloc] initWithTarget:textField nilValue:nil];
        [subscriptingAssignmentTrampoline setObject:modelTerminal forKeyedSubscript:keyPath];
        [textField.rac_textSignal subscribe:modelTerminal];
    }else if ([UIKit isKindOfClass:[UITextView class]])// UITextView
    {
        UITextView *textView = (UITextView *)UIKit;
        RACChannelTerminal *modelTerminal = [[RACKVOChannel alloc] initWithTarget:model keyPath:property nilValue:nil][@"followingTerminal"];
        RACSubscriptingAssignmentTrampoline *subscriptingAssignmentTrampoline = [[RACSubscriptingAssignmentTrampoline alloc] initWithTarget:textView nilValue:nil];
        [subscriptingAssignmentTrampoline setObject:modelTerminal forKeyedSubscript:keyPath];
        [textView.rac_textSignal subscribe:modelTerminal];
    }
}

@end

//
//  UIButton+LZButton.h
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/8.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

@interface UIButton (LZButton)

- (void)lz_buttonForControlEvents:(UIControlEvents)controlEvents block:(void (^)(id x))lz_ButtonBlock;

@end

//
//  UIGestureRecognizer+LZGestureRecognizer.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/9.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIGestureRecognizer+LZGestureRecognizer.h"

@implementation UIGestureRecognizer (LZGestureRecognizer)

- (void)lz_gestureRecognizerWithBlock:(void (^)(id x))lz_GestureRecognizerBlock{
    [[self rac_gestureSignal] subscribeNext:^(id x) {
        lz_GestureRecognizerBlock(x);
    }];
}

@end

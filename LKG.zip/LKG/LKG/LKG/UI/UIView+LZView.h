//
//  UIView+LZView.h
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

@interface UIView (LZView)

- (void)LZ_bind_UIKit:(id)UIKit KeyPath:(id)keyPath Model:(NSObject *)model Property:(id)property;

@end

//
//  UIRefreshControl+LZRefreshControl.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/9.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UIRefreshControl+LZRefreshControl.h"

@implementation UIRefreshControl (LZRefreshControl)

- (void)lz_refreshControlWithInput:(id)input Block:(void (^)(id x))lz_RefreshControlBlock{
    [[self.rac_command execute:input] subscribeNext:^(id x) {
        lz_RefreshControlBlock(x);
    }];
}

- (void)lz_refreshControlForControlEvents:(UIControlEvents)controlEvents block:(void (^)(id x))lz_RefreshControlBlock{
    [[self rac_signalForControlEvents:controlEvents]
     subscribeNext:^(id x) {
         lz_RefreshControlBlock(x);
     }];
}

@end

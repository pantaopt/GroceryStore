//
//  UISegmentedControl+LZSegmentedControl.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/9.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UISegmentedControl+LZSegmentedControl.h"

@implementation UISegmentedControl (LZSegmentedControl)

- (void)lz_segmentedControlWithNilValue:(NSNumber *)nilValue Block:(void (^)(id x))lz_SegmentedControlBlock{
    [[self rac_newSelectedSegmentIndexChannelWithNilValue:nilValue] subscribeNext:^(id x) {
        lz_SegmentedControlBlock(x);
    }];
}

@end

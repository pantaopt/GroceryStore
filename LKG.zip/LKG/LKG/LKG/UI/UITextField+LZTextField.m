//
//  UITextField+LZTextField.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/8.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UITextField+LZTextField.h"

@implementation UITextField (LZTextField)

- (void)lz_textFieldWithBlock:(void (^)(id x))lz_TextFieldBlock{
    //    @weakify(self);
    [self.rac_textSignal subscribeNext:^(id x) {
        //        @strongify(self);
        lz_TextFieldBlock(x);
    }];
}

@end

//
//  UISlider+LZSlider.m
//  试一下ReactiveViewModel
//
//  Created by 潘涛 on 2017/3/9.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "UISlider+LZSlider.h"

@implementation UISlider (LZSlider)

- (void)lz_sliderWithNilValue:(NSNumber *)nilValue Block:(void (^)(id x))lz_SliderBlock{
    [[self rac_newValueChannelWithNilValue:nilValue] subscribeNext:^(id x) {
        lz_SliderBlock(x);
    }];
}

@end

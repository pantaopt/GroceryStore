//
//  LZMediator+One.h
//  LKG
//
//  Created by 潘涛 on 2017/8/16.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "LZMediator.h"

@interface LZMediator (One)

- (void)adjustAnotherComponentMethodOne;

@end

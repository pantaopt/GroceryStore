//
//  LZMediator+One.m
//  LKG
//
//  Created by 潘涛 on 2017/8/16.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "LZMediator+One.h"

NSString * const kLZMediatorTargetComponent           = @"Component2";
NSString * const kLZMediatorActionComponentMethod     = @"methodOne";

@implementation LZMediator (One)

- (void)adjustAnotherComponentMethodOne
{
    [self performTarget:kLZMediatorTargetComponent
                 action:kLZMediatorActionComponentMethod
                 params:nil
      shouldCacheTarget:YES];
}

@end

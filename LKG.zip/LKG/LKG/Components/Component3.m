//
//  Component3.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component3.h"

@interface Component3 (){
    float _kScreenWidth;
    float _kScreenHeight;
}

@end


@implementation Component3

- (void)viewDidLoad{
    NSLog(@"viewDidLoad - Component3  ");
    [super viewDidLoad];
    
    UILabel *L3 = [[UILabel alloc] init];
//    L3.text = @"组件3";
    L3.backgroundColor = [UIColor clearColor];
    L3.yoga.isEnabled = YES;
    L3.yoga.flexGrow = 1;
    L3.textColor = [UIColor blackColor];
    L3.font = [UIFont systemFontOfSize:15];
    L3.textAlignment = NSTextAlignmentCenter;
    [self addSubview:L3];
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear - Component3  ");
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear - Component3  ");
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear - Component3  ");
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    NSLog(@"viewDidDisappear - Component3  ");
    [super viewDidDisappear:animated];
}

@end

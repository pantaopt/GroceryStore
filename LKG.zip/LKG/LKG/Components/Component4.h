//
//  Component4.h
//  LKG
//
//  Created by 潘涛 on 2017/3/15.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component.h"

@interface Component4 : Component

@end

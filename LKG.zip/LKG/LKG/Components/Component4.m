//
//  Component4.m
//  LKG
//
//  Created by 潘涛 on 2017/3/15.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component4.h"

@implementation Component4

- (void)viewDidLoad{
    NSLog(@"viewDidLoad - Component4  ");
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear - Component4  ");
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear - Component4  ");
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear - Component4  ");
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    NSLog(@"viewDidDisappear - Component4  ");
    [super viewDidDisappear:animated];
}

@end

//
//  Component1.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component1.h"
#import "LZMediator+One.h"

@interface Component1 (){
    float _kScreenWidth;
    float _kScreenHeight;
}

@property (nonatomic, strong) NSString *responseData;

@end

@implementation Component1

- (void)viewDidLoad{
    NSLog(@"viewDidLoad - Component1  ");
    [super viewDidLoad];
    
    __weak typeof(self)weakSelf = self;
    [self requestWithMethod:GET Url:@"1.json" Parameter:nil DownloadProgress:^(NSProgress *downloadProgress) {
        NSLog(@"%.2f",downloadProgress.fractionCompleted);
    } SuccessBlock:^(id responseBody) {
        //        NSLog(@" -1- %@",responseBody);
        [weakSelf requestWithMethod:GET Url:@"2.json" Parameter:nil DownloadProgress:^(NSProgress *downloadProgress) {
            NSLog(@"%.2f",downloadProgress.fractionCompleted);
        } SuccessBlock:^(id responseBody) {
            //            NSLog(@" -2- %@",responseBody);
            weakSelf.responseData = responseBody;
        } FailureBlock:^(NSDictionary *error) {
            NSLog(@"error: %@",error);
        }];
    } FailureBlock:^(NSDictionary *error) {
        NSLog(@"error: %@",error);
    }];
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear - Component1  ");
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear - Component1  ");
    [super viewDidAppear:animated];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        NSLog(@" ------  %@",self.responseData);
    });
    
}

- (void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear - Component1  ");
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    NSLog(@"viewDidDisappear - Component1  ");
    [super viewDidDisappear:animated];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [[LZMediator sharedInstance] adjustAnotherComponentMethodOne];
}

@end

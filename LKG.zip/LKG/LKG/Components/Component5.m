//
//  Component5.m
//  LKG
//
//  Created by 潘涛 on 2017/3/15.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component5.h"

@interface Component5 (){
    float _kScreenWidth;
    float _kScreenHeight;
}

@end

@implementation Component5

- (void)viewDidLoad{
    NSLog(@"viewDidLoad - Component5  ");
    [super viewDidLoad];
    
    UILabel *L5 = [[UILabel alloc] init];
    L5.text = @"组件5";
    L5.yoga.isEnabled = YES;
    L5.yoga.isIncludedInLayout = NO;
    L5.frame = CGRectMake(0, 0, 200, 50);
    L5.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.3];
    L5.textColor = [UIColor blackColor];
    L5.font = [UIFont systemFontOfSize:15];
    L5.textAlignment = NSTextAlignmentCenter;
    [self addSubview:L5];
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear - Component5  ");
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear - Component5  ");
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear - Component5  ");
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    NSLog(@"viewDidDisappear - Component5  ");
    [super viewDidDisappear:animated];
}

@end

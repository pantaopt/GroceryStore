//
//  Component2.m
//  LKG
//
//  Created by 潘涛 on 2017/3/14.
//  Copyright © 2017年 潘涛. All rights reserved.
//

#import "Component2.h"
#import "LZUIKit.h"

@interface Component2 (){
    float _kScreenWidth;
    float _kScreenHeight;
}

@end

@implementation Component2

- (void)viewDidLoad{
    NSLog(@"viewDidLoad - Component2  ");
    [super viewDidLoad];
    self.yoga.flexDirection = YGFlexDirectionColumn;
    
    
    UILabel *L2 = [[UILabel alloc] init];
//    L2.text = @"组件2-1";
    L2.backgroundColor = [UIColor grayColor];
    L2.yoga.isEnabled = YES;
    L2.yoga.flexGrow = 1;
    L2.textColor = [UIColor blackColor];
    L2.font = [UIFont systemFontOfSize:15];
    L2.textAlignment = NSTextAlignmentCenter;
    [self addSubview:L2];
    
    UILabel *L23 = [[UILabel alloc] init];
//    L23.text = @"组件2-3";
    L23.backgroundColor = [UIColor brownColor];
    L23.yoga.isEnabled = YES;
    L23.yoga.flexGrow = 1;
    L23.textColor = [UIColor blackColor];
    L23.font = [UIFont systemFontOfSize:15];
    L23.textAlignment = NSTextAlignmentCenter;
    [self addSubview:L23];
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"viewWillAppear - Component2  ");
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"viewDidAppear - Component2  ");
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    NSLog(@"viewWillDisappear - Component2  ");
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    NSLog(@"viewDidDisappear - Component2  ");
    [super viewDidDisappear:animated];
}

- (void)methodOne:(NSDictionary *)params
{
    NSLog(@"methodOne");
}

@end
